import React from 'react';
import ColorView from '../ColorView';
import Helm from '../Helm';
import { Button } from 'antd';

export default class Sending extends React.Component{

  render() {

    return (
      <div>
        <ColorView clickable={true}/>
        <Helm disabled={false}/>
        <Button type="primary">发送</Button>
      </div>
    )
  }
}