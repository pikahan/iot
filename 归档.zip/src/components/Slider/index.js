import React from 'react';
import { Slider, InputNumber, Row, Col } from 'antd';

export default class MySlider extends React.Component {
  static defaultProps = {
    disabled: true,
    value: 0
  }
  state = {
    inputValue: this.props.value,
  };



  onChange = value => {
    this.setState({
      inputValue: value,
    });
  };

  render() {
    const { inputValue } = this.state;
    const { disabled } = this.props;
    return (
      <Row>
        <Col span={12}>
          <Slider
            disabled={disabled}
            min={0}
            max={100}
            onChange={this.onChange}
            value={typeof inputValue === 'number' ? inputValue : 0}
          />
        </Col>
        <Col span={4}>
          <InputNumber
            disabled={disabled}
            min={0}
            max={100}
            style={{ marginLeft: 16 }}
            value={inputValue}
            onChange={this.onChange}
          />
        </Col>
      </Row>
    );
  }
}
